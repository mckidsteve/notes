#include <iostream>
#include <fstream>
#include <chrono>

using namespace std;
using namespace chrono;

// 读取输入文件中的数据
// 返回一个包含所有数据的向量
void read_input_file(float dat[]) {
    ifstream input_file("input.txt" , ios::in);
    if(!input_file.is_open())
    {
        std::cerr<<"cannot open the file";
    }
    float value;
    int i = 0;

    while (input_file >> value) {
        dat[i] = value;
//         cout << dat[i] << '\n';
        i ++;
    }

    input_file.close();
}


// 计算全天的等效声级
// req_inv : L_eq = 10 * lg (sum(T_i * 10^{0.1 * Leq_Ti}) / T) ;
// @para: L_eq : 24h等效连续A声级 , T_i : 时间段ti , Leq_Ti : ti时间段等效声级 , T : 总时间段之和
// 返回Leq
void cal_sound_level(float *data , const int N ,float *sum , float *total_time) {

    int index = threadIdx.x + blockIdx.x * blockDim.x;
    int stride = blockDim.x * gridDim.x ;

    for (int i = index; i < N; i += stride){
        float time = (i+1) * 1.0; // 时间间隔,单位为秒
        float Leq_ti = data[i]; // 等效连续A声级
// printf("%f\n" , Leq_ti);
        sum[0] += time * pow(10 , 0.1 * Leq_ti);
        // printf("%f" , time);
        total_time[0] += time;
    }

}

int main() {
    // system("chcp 65001");

     ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);

    const int N = 10000000 + 10;
    size_t size = N * sizeof(float);
    float *data = new float[N] ;
    read_input_file(data);

    float Leq = 0.0;
    float *sum = new float[N] ;
    float *total_time = new float[N] ;



    auto start = system_clock::now();
    cal_sound_level(data , N , sum, total_time);


    Leq =  10.0 * log10(sum[0] / total_time[0]); // 返回全天的等效声级

    auto end = system_clock::now();
    auto duration = duration_cast<microseconds>(end - start);
    printf("全天的等效声级为: %f dB\n" , Leq);
    cout << "Time Cost:" << double(duration.count()) * microseconds::period::num / microseconds::period::den << "s\n";

    Delete data;

    return 0;
}

#include <bits/stdc++.h>
using namespace std;
const int N = 500 + 10;

int n, m;
int dis[N][N];
long long g[N][N];
int dx[] = {0, 0, 1, -1}, dy[] = {1, -1, 0, 0};
bool bfs(int k)
{
    memset(dis, 0x3f, sizeof(dis));
    dis[1][1] = 0;
    deque<pair<int, int>> q;
    q.push_back({1, 1});
    while (!q.empty())
    {
        pair<int, int> now;
        now = q.front(); q.pop_front();
        int x = now.first, y = now.second;
        for (int i = 0; i < 4; i++)
        {
            int nx = x + dx[i], ny = y + dy[i];
            if (nx < 1 || ny < 1 || nx > n || ny > m || g[nx][ny] - g[x][y] > 2 * k)
                continue;
            int cost = g[nx][ny] - g[x][y] <= k ? 0 : 1;
            if (dis[nx][ny] > dis[x][y] + cost)
            {
                dis[nx][ny] = dis[x][y] + cost;
                if (cost) q.push_back({nx, ny});
                else q.push_front({nx, ny});
            }
        }
    }
    return dis[n][m] <= floor(sqrt(k));
}

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            cin >> g[i][j];
    int l = 1, r = 1e9 + 1;
    while (l < r)
    {
        int mid = (l + r) >> 1;
        if (bfs(mid)) r = mid;
        else l = mid + 1;
    }
    if (l == 1e9 + 1) l = -1;
    cout << l;
    return 0;
}
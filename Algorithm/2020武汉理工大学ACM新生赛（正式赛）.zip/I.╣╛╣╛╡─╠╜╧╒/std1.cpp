#include <bits/stdc++.h>
using namespace std;
const int N = 500 + 10;
int n, m;
long long g[N][N];
int dis[N][N], vis[N][N];
int dx[] = {0, 0, 1, -1}, dy[] = {1, -1, 0, 0};
bool dij(int k)
{
    memset(dis, 0x3f, sizeof(dis));
    memset(vis, 0, sizeof(vis)); //是否已出队
    priority_queue<pair<int, pair<int, int>>, vector<pair<int, pair<int, int>>>, greater<pair<int, pair<int, int>>>> q;
    dis[1][1] = 0;
    q.push({dis[1][1], {1, 1}});
    while (!q.empty())
    {
        int x = q.top().second.first, y = q.top().second.second; q.pop();
        if (vis[x][y]) continue; vis[x][y] = 1;
        for (int i = 0; i < 4; i++)
        {
            int nx = x + dx[i], ny = y + dy[i];
            if (nx < 1 || ny < 1 || nx > n || ny > m || g[nx][ny] - g[x][y] > 2 * k)
                continue;
            int cost = g[nx][ny] - g[x][y] <= k ? 0 : 1;
            if (dis[nx][ny] > dis[x][y] + cost)
            {
                dis[nx][ny] = dis[x][y] + cost;
                q.push({dis[nx][ny], {nx, ny}});
            }
        }
    }
    return dis[n][m] <= floor(sqrt(k));
}

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            cin >> g[i][j];
    int l = 1, r = 1e9 + 1;
    while (l < r)
    {
        int mid = (l + r) >> 1;
        if (dij(mid)) r = mid;
        else l = mid + 1;
    }
    if (l == 1e9 + 1) l = -1;
    cout << l;
    return 0;
}

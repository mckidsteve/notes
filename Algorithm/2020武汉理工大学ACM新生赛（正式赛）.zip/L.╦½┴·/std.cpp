#include<iostream>
using namespace std;
//ryuujinnokenwokue
//ryuugawagatekiwokurau
int main() {
    int T; cin >> T;
    int X, Y, Z;
    while (T--) {
        cin >> X >> Y >> Z;
        if (X&1 && Y&1 && Z&1) {
            cout << "ryuugawagatekiwokurau" << endl;
        } else {
            cout << "ryuujinnokenwokue" << endl;
        }
    }
}
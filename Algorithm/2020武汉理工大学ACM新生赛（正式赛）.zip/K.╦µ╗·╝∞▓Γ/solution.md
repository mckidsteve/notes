随机检测

题意：问从0变化到n，再由n变化到0，相邻两个数二进制形式变化的位数之和。

题解：担心有人根据样例直接看出结论是$2n$，加了取模来迷惑人。由于n、p很大，时间复杂度要么$O(logn)$，要么$O(1)$。
事实上，两种解法都可行。虽然可以依次考虑相邻两个数变化的位数，最后加起来来找规律。但本题有一个巧妙的思路，由于二进制形式
各位独立，可以依次考虑各位的变化次数，最低位每隔一个数变化一次，次低位每个两个数变化一次，...，以此类推。
那么答案为$n+\lfloor\frac{n}{2}\rfloor+\lfloor\frac{n}{2^2}\rfloor+...+1+n二进制下为1的位数$，这已经可以$O(logn)$解决了。
下面证明一下为什么结论就是$2n$
$n=n_{end}+\lfloor\frac{n}{2}\rfloor+\lfloor\frac{n}{2}\rfloor n_{end}表示n二进制形式下最后一位$
$\lfloor\frac{n}{2}\rfloor=\lfloor\frac{n}{2}\rfloor_{end}+\lfloor\frac{n}{4}\rfloor+\lfloor\frac{n}{4}\rfloor$
...
那么$n=n_{end}+\lfloor\frac{n}{2}\rfloor_{end}+...+n_{first}+\lfloor\frac{n}{2}\rfloor+\lfloor\frac{n}{2^2}\rfloor+...+1   n_{first}表示n二进制形式下最高$
得证。






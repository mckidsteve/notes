#include<cstdio>
#include<iostream>
#define ll long long
using namespace std;

int main(){
    ll n,sac;
    scanf("%lld%lld",&n,&sac);
    printf("%lld\n",2*n%sac);
}

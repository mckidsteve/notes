#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 10;
const int INF = 0x3f3f3f3f;

int ans[N];
struct node
{
    int val, pos;
    bool operator<(const node &next) const &
    {
        return (val < next.val || val == next.val && pos < next.pos);
    }
} a[N];

int main()
{
    memset(ans, 0x3f, sizeof(ans));
    int n; cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i].val;
        a[i].pos = i;
    }
    sort(a + 1, a + 1 + n);
    for (int i = 1; i <= n; i++)
    {
        int pre = i - 1, nxt = i + 1;
        if (pre > 0 && a[pre].val == a[i].val)
            ans[a[i].pos] = min(ans[a[i].pos], a[i].pos - a[pre].pos);
        if (nxt <= n && a[nxt].val == a[i].val)
            ans[a[i].pos] = min(ans[a[i].pos], a[nxt].pos - a[i].pos);
        if (ans[a[i].pos] == INF) ans[a[i].pos] = -1;
    }
    for (int i = 1; i <= n; i++)
    {
        cout << ans[i] << " ";
    }
    return 0;
}
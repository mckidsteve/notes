#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 10;
const int INF = 0x3f3f3f3f;
int a[N], ans[N], last[N];
int main()
{
    memset(ans, 0x3f, sizeof(ans));
    int n; cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 1; i <= n; i++)
    {
        if (last[a[i]])
        {
            ans[i] = min(ans[i], i - last[a[i]]);
            ans[last[a[i]]] = min(ans[last[a[i]]], i - last[a[i]]);
        }
        last[a[i]] = i;
    }
    for (int i = 1; i <= n; i++)
    {
        if (ans[i] == INF) cout << -1 << " ";
        else cout << ans[i] << " ";
    }
    return 0;
}
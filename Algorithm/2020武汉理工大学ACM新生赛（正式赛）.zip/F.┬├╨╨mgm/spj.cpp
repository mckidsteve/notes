#include<cstdio>
#include<cmath>
#define AC 0
#define WA 1
using namespace std;

int main(int argc, char *args[]) {
    FILE *f_in = fopen(args[1], "r");
    FILE *f_out = fopen(args[2], "r");
    FILE *f_ans = fopen(args[3], "r");
    double solution;
    while (fscanf(f_ans, "%lf", &solution) != EOF) {   
        double output;
        if (fscanf(f_out, "%lf", &output) == EOF || fabs(output-solution) > 0.01) {
            return WA;
        }
        /* code */
    }
    return AC;
}
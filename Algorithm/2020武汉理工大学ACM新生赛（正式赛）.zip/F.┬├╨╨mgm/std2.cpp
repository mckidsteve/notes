#include<iostream>
#include<cmath>
#include<cstdio>
const int MAXN = 5e4 + 10;
const double pi = acos(-1.0);
using namespace std;

struct matrix {

    double m[3][3];
    matrix() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) 
                m[i][j] = 0;
        }
        for (int i = 0; i < 3; i++) {
            m[i][i] = 1;
        }
    }
    void init() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) 
                m[i][j] = 0;
        }
        for (int i = 0; i < 3; i++) {
            m[i][i] = 1;
        }
    }

    void print() {
        	for (int i = 0; i < 3; i++){
			for (int j = 0; j < 3; j++)
				printf("%lf ", m[i][j]);
			puts("");
		}
    }

};

matrix operator *(const matrix &a, const matrix &b) {
    matrix res;
    for (int i = 0; i < 3; i++) 
        for (int j = 0; j < 3; j++)
            res.m[i][j] = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            for (int k = 0; k < 3; k++) {
                res.m[i][j] += a.m[i][k]*b.m[k][j];
            }
        }
    }
    return res;
}

matrix tree[MAXN<<2|1];

void update(int x, int num, int l, int r, matrix temp) {
    if (l == x && r == x) {
        tree[num] = temp;
        return;
    }
    int mid = (l + r) >> 1;
    if (x <= mid) update(x, num<<1, l, mid, temp);
    else update(x, num<<1|1, mid+1, r, temp);
    tree[num].init();
    tree[num] = tree[num] * tree[num<<1|1];
    tree[num] = tree[num] * tree[num<<1];
}

matrix query(int num, int l, int r, int L, int R) {
    if (l == L && r == R) {
        return tree[num];
    }

    int mid = (L + R) >> 1;
    if (r <= mid) {
        return query(num<<1, l, r, L, mid);
    }
    if (l > mid) {
        return query(num<<1|1, l, r, mid+1, R);
    }
    return query(num<<1|1, mid+1, r, mid+1, R) * query(num<<1, l, mid, L, mid) ;
}

int main() {
    int N, M;
    cin >> N >> M;
    for (int i = 1; i <= N; i++) {
        int operation;
        cin >> operation;
        if (operation == 1) {
            double dx, dy;
            cin >> dx >> dy;
            matrix base;
            base.init();
            base.m[0][2] = dx;
            base.m[1][2] = dy;
            update(i, 1, 1, N, base);
        } else {
            double angle;
            cin >> angle;
            angle=2*pi*angle/360;
            matrix base;
            base.init();
            base.m[0][0] = cos(angle);
            base.m[0][1] = -sin(angle);
            base.m[1][0] = sin(angle);
            base.m[1][1] = cos(angle);
            update(i, 1, 1, N, base);
        }
    }

    while (M--) {
        int l, r;
        cin >> l >> r;
        matrix ans = query(1, l, r, 1, N);
        printf("%.3lf %.3lf\n", ans.m[0][2], ans.m[1][2]);
    }
    return 0;
}
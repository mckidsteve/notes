前置知识：矩阵乘法

构造平移矩阵
$$
\left[ \begin{matrix}
1&0&dx\\
0&1&dy\\
0&0&1
\end{matrix} \right]
$$
左乘初始坐标
$$
\left[ \begin{matrix}
x'\\
y'\\
1
\end{matrix} \right]
=\left[ \begin{matrix}
1&0&dx\\
0&1&dy\\
0&0&1
\end{matrix} \right]
\left[ \begin{matrix}
x\\
y\\
1
\end{matrix} \right]
$$

$$
\left[ \begin{matrix}
x'\\
y'\\
1
\end{matrix} \right]
=
\left[ \begin{matrix}
1*x+0*y+dx*1\\
0*x+1*y+dy*1\\
0*x+0*y+1*1
\end{matrix} \right]
=\left[ \begin{matrix}
x+dx\\
y+dy\\
1
\end{matrix} \right]
$$

构造旋转矩阵
$$
\left[ \begin{matrix}
cos\theta&-sin\theta&0\\
sin\theta&cos\theta&0\\
0&0&1
\end{matrix} \right]
$$

$$
\left[ \begin{matrix}
x'\\
y'\\
1
\end{matrix} \right]
=\left[ \begin{matrix}
cos\theta&-sin\theta&0\\
sin\theta&cos\theta&0\\
0&0&1
\end{matrix} \right]
\left[ \begin{matrix}
x\\
y\\
1
\end{matrix} \right]=
\left[ \begin{matrix}
x*cos\theta-y*sin\theta\\
x*sin\theta+y*cos\theta\\
1
\end{matrix} \right]
$$



有了矩阵的运算作为基础，可以把问题简化为如何计算区间内的变换矩阵相乘的结果

方法1：前缀和思想，计算所有矩阵的相乘的结果，查询时乘上前面i-1项相乘的结果的逆矩阵,预处理复杂度$O(N)$

方法2：线段树维护一个区间矩阵相乘的结果，复杂度$O(M*logN)$
#include<iostream>
using namespace std;
long long n,k,minv[100005],a[100005],cnt[100005],ans;
int main(){
	cin>>n>>k;
	for(int i=0;i<=k;i++){
		minv[i]=1e10;
	}
	long long x,xx;
	for(int i=1;i<=n;i++){
		cin>>x;
		xx=x%k;
		a[xx]+=x*x;
		cnt[xx]++;
		minv[xx]=min(minv[xx],x);
	}
	for(int i=0;i*2<=k;i++){
		if(i==0&&cnt[0]){
			ans+=minv[0]*minv[0];
			continue;
		}
		if(cnt[i]&&cnt[k-i]){
			ans+=min(minv[k-i]*minv[k-i],minv[i]*minv[i]);
		}
		else{
			if(cnt[i])ans+=a[i];
			if(cnt[k-i])ans+=a[k-i];
		}
	}
	cout<<ans<<endl;
}

#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;

int pile[20], cnt, lft, pos;
int carda, cardb, statusa, statusb;
int outer[10] = {0};


bool must_win(int hand, int discard, int opposite, int status) {
    int op = hand == carda?cardb:carda;
    if (outer[0] == 0) {
        opposite = op;
    }
    if (status) return false;
    int oter[10];
    memcpy(oter, outer, sizeof(outer));
    if (op == -1) oter[0]++, oter[op]++;
    // 手牌比未知牌都大
    bool flag = true;
    for (int i=8; i>=hand; i--) {
        if (oter[i] != 0) {flag = false;break;}
    }
    // 对面没保护
    if (!status) {
        if (opposite == -1) {
            if (discard == 3 && flag) {
                // 手上有男爵并且外面的牌都确定小于自己另一张牌
                return true;
            }
        // 确定对面的牌
        } else {
            /*
            * 1. 弃守卫
            * 2. 弃男爵，对面比自己小
            * 3. 弃王子，对面是8
            * 4. 弃王子，对面是3，剩下所有牌都比自己小
            */
            if (discard == 1) return true;
            else if (discard == 3 && opposite < hand) return true;
            else if (discard == 5) {
                if (opposite == 8) return true;
                else if (opposite == 3 && flag) return true;
            }
        }
    }
    
    // // 考虑最后一轮胜利
    // int pile_num = opposite == -1?oter[0]-1:oter[0];
    // if (pile_num <= 2) {
    //     /*
    //      * 1. 弃女仆，手里比剩下的牌高
    //      * 2. 如果剩余牌中还有6或5，不会必赢
    //      * 3. 弃王子，剩余牌比自己小
    //      * 4. 弃国王，对手牌比剩下所有都大
    //      * 5. 如果对手手牌有5或者6，不会必赢
    //      * 6. 如果对手手牌是3且我方手牌不大于剩余所有牌不会必赢
    //      */
    //     // 场上还有1，就可能翻盘
    //     if (oter[1]) return false;
    //     if (discard == 4 && flag && hand > opposite) {
    //         return true
    //     } else {
    //         oter[opposite]--;
    //         if (pile_num == 2 || oter[5] != 0 || oter[6] != 0 || oter[3] != 0) {
    //             oter[opposite]++;
    //             return false;
    //         }
    //         oter[opposite]++;
    //     } else if (discard == 5 && opposite != 6 && flag) return true;
    //     else if (pile_num == 1 && discard == 5 && opposite == 6 && hand < lft) return true;
    //     else if (discard == 6 && opposite > hand) {
    //         bool flag_1 = false;
    //         for (int i=8; i>=opposite; i--) {
    //             if (oter[i] != 0) flag_1 = {false;break;}
    //         }
    //         if (flag_1) return true;
    //     } else if (pile_num == 2) {
    //         if (opposite == 5 || opposite == 6) return false;
    //         else if (opposite == 3 && !flag) return false;
    //     } else {
    //         if (flag) return true;
    //     }
    // }
    return false;
}

bool must_lose(int hand, int discard, int opposite, int knowme, int status, int statusyou)
{
    if (discard == 8) return true;
    if (status) return false;
    // 有1就还能翻盘
    if (discard == 1 && !statusyou) return false;
    int op = hand == carda?cardb:carda;
    if (outer[0] == 0) {
        opposite = op;
    }
    int oter[10];
    memcpy(oter, outer, sizeof(outer));
    if (op == -1) oter[0]++, oter[op]++;
    // 手牌比未知牌小
    bool flag = true;
    for (int i=1; i<=hand; i++) {
        if (oter[i] != 0) {flag = false;break;}
    }
    // 对面手牌比未知牌小
    bool flag_1 = true;
    for (int i=1; i<=opposite; i++) {
        if (oter[i] != 0) {flag = false;break;}
    }
    // 不知道对面的牌
    if (opposite == -1) {
        if (discard == 3 && flag) 
            // 手上有男爵并且外面的牌都确定大于自己另一张牌
            return true;
    } else {
        /*
         * 对面知道本方的剩余牌, 并且没打女仆
         * 对面牌是守卫，并且本方未弃掉国王，或者弃掉国王并且本方也是守卫
         * 对面牌是男爵，并且本方牌小于剩余牌，并且本方未弃掉国王，或者弃掉国王本方也是男爵
         * 对面牌是王子，并且本方是公主，并且本方未弃掉国王/王子
        */

        if (knowme != -1 && discard != 4) {
            if (opposite == 1 && (discard != 6 || (discard == 6 && hand == 1))) return true;
            else if (opposite == 3 && flag && (discard != 6 || (discard == 6 && hand == 3))) return true;
            else if (opposite == 5 && hand == 8 && discard != 6 && discard != 5) return true;
        }
        /*
         * 弃国王, 并且还有下一轮
         * 手上1
         * 手上5，对面8
         * 手上3， 对面牌比所有都小
         */
        else if (discard == 6 && outer[0] > 1) {
            if (hand == 1) return true;
            else if (hand == 5 && opposite == 8) return true;
            else if (hand == 3 && flag_1)  return true;
        } 
        /*
         * 弃王子
         * 对面国王，手上守卫
         * 对面男爵，己方牌小
         */
        else if (discard == 5) {
            if (outer[0]>2 && opposite == 6 && hand == 1) return true;
            else if (opposite == 3 && flag) return true;
        }
    }
    // /*
    //  * 考虑最后一轮
    //  * 弃守卫有翻盘希望
    //  * 手上有守卫并且剩余牌有5
    //  */
    // int pile_num = opposite == -1?oter[0]-1:oter[0];
    // if (pile_num <= 2) {
    //     if (discard == 1) return false;
    //     else if (hand == 1 && (opposite == 5 || (oter[5] && opposite == -1 && !status))) return false;
    //     if (discard == 5) 
    // }
    return false;
}

double operate(int &hand, int &discard, int &opposite, int& knowme, int& knowyou, int& statusme, int& statusyou) 
{
    if (discard != 4) statusme = 0;
    if (discard!=4 && discard != 7 && statusyou) return 0;

    if (discard == 1) {
        return 1/8.0;
    } else if (discard == 2) {
        knowyou = opposite;
    } else if (discard == 3) {
        if (hand > opposite) return 1;
        else if (hand < opposite) return -1;
        else {
            knowme = hand;
            knowyou = opposite;
        }
    } else if (discard == 4) {
        statusme = 1;
    } else if (discard == 5) {  
        int newcard = pos==cnt?lft:pile[++pos];
        outer[newcard]--;
        outer[0]--;      
        if (opposite == 8) return 1;
        else if (opposite == 6) {
            opposite = hand;
            hand = newcard;
            knowme = hand;
            knowyou = opposite;
        } else if (opposite == 4) {
            opposite = newcard;
            statusyou = true;
        } else if (opposite == 3) {
            opposite = newcard;
            knowme = hand;
            knowyou = opposite;
            if (hand > opposite) return 1;
            else if (hand < opposite) return -1;
            else {
                knowme = hand;
                knowyou = opposite;
            }
        } else if (opposite == 2) {
            opposite = newcard;
            knowme = hand;
        } else if (opposite == 1) {
            opposite = newcard;
            if (knowme != -1) return -1; 
            return -1/8.0;
        } else {
            opposite = newcard;
        }
    } else if (discard == 6) {
        swap(hand, opposite);
        knowme = hand;
        knowyou = opposite;
    } 
    return 0;
} 

double calc_win_rate(int who, int know_a, int know_b) {
    if (pos == cnt) {
        if (carda > cardb) return 1;
        else return 0;
    } 
    int newcard = pile[++pos];
    outer[newcard]--;
    outer[0]--;
    if (who == 0) {  
        double rate1 = -1, rate2 = -1;
        if (must_win(carda, newcard, know_b, statusb)) {
            rate1 = 1;
        } else if (must_win(newcard, carda, know_b, statusb)) {
            rate2 = 1;
        }
        if (rate1 == 1 || rate2 == 1) return 1;
        if (!must_lose(carda, newcard, know_b, know_a, statusa, statusb)) {
            int t_carda = carda, t_cardb = cardb, t_pos = pos, t_statusa = statusa, t_statusb = statusb, t_knowa = know_a, t_knowb = know_b;
            int tmp1[20], tmp2[20];
            memcpy(tmp1, pile, sizeof(pile));
            memcpy(tmp2, outer, sizeof(outer));
            if (newcard == know_a) know_a = -1;
            double rate = operate(carda, newcard, cardb, know_a, know_b, statusa, statusb);
            rate1 = calc_win_rate(1, know_a, know_b);
            rate1 = rate>0?rate+(1-rate)*rate1:(1+rate)*rate1;
            memcpy(pile, tmp1, sizeof(pile));
            memcpy(outer, tmp2, sizeof(outer));
            carda = t_carda, cardb = t_cardb, pos = t_pos, statusa = t_statusa, statusb = t_statusb, know_a = t_knowa, know_b = t_knowb;
        }
        if (!must_lose(newcard, carda, know_b, know_a, statusa, statusb)) {
            int t_carda = carda, t_cardb = cardb, t_pos = pos, t_statusa = statusa, t_statusb = statusb, t_knowa = know_a, t_knowb = know_b;
            int tmp1[20], tmp2[20];
            memcpy(tmp1, pile, sizeof(pile));
            memcpy(tmp2, outer, sizeof(outer));
            swap(newcard, carda);
            if (newcard == know_a) know_a = -1;
            double rate = operate(carda, newcard, cardb, know_a, know_b, statusa, statusb);
            rate2 = calc_win_rate(1, know_a, know_b);
            rate2 = rate>0?rate+(1-rate)*rate2:(1+rate)*rate2;
            swap(newcard, carda);
            memcpy(pile, tmp1, sizeof(pile));
            memcpy(outer, tmp2, sizeof(outer));
            carda = t_carda, cardb = t_cardb, pos = t_pos, statusa = t_statusa, statusb = t_statusb, know_a = t_knowa, know_b = t_knowb;
        }
        if (rate1 == -1 && rate2 == -1) return 0;
        else if (rate1 == -1 || (carda == 7 && (newcard == 5 || newcard == 6))) return rate2;
        else if (rate2 == -1 || (newcard == 7 && (carda == 5 || carda == 6))) return rate1;
        else {
            return 0.5*rate1+0.5*rate2;
        }
    } else { 
        double rate1 = -1, rate2 = -1;
        if (must_win(cardb, newcard, know_a, statusb)) {
            rate1 = 1;
        } else if (must_win(newcard, cardb, know_a, statusb)) {
            rate2 = 1;
        }
        if (rate1 == 1 || rate2 == 1) return 0;
        if (!must_lose(cardb, newcard, know_a, know_b, statusb, statusa)) {
            int t_carda = carda, t_cardb = cardb, t_pos = pos, t_statusa = statusa, t_statusb = statusb, t_knowa = know_a, t_knowb = know_b;
            int tmp1[20], tmp2[20];
            memcpy(tmp1, pile, sizeof(pile));
            memcpy(tmp2, outer, sizeof(outer));
            if (newcard == know_b) know_b = -1;
            double rate = operate(cardb, newcard, carda, know_b, know_a, statusb, statusa);
            rate1 = calc_win_rate(0, know_a, know_b);
            rate1 = rate<0?-rate+(1+rate)*rate1:(1-rate)*rate1;
            memcpy(pile, tmp1, sizeof(pile));
            memcpy(outer, tmp2, sizeof(outer));
            carda = t_carda, cardb = t_cardb, pos = t_pos, statusa = t_statusa, statusb = t_statusb, know_a = t_knowa, know_b = t_knowb;
        }
        if (!must_lose(newcard, cardb, know_a, know_b, statusb, statusa)) {
            int t_carda = carda, t_cardb = cardb, t_pos = pos, t_statusa = statusa, t_statusb = statusb, t_knowa = know_a, t_knowb = know_b;
            int tmp1[20], tmp2[20];
            memcpy(tmp1, pile, sizeof(pile));
            memcpy(tmp2, outer, sizeof(outer));
            swap(cardb, newcard);
            if (newcard == know_b) know_b = -1;
            double rate = operate(cardb, newcard, carda, know_b, know_a, statusb, statusa);
            rate2 = calc_win_rate(0, know_a, know_b);
            rate2 = rate<0?-rate+(1+rate)*rate2:(1-rate)*rate2;
            swap(cardb, newcard);
            memcpy(pile, tmp1, sizeof(pile));
            memcpy(outer, tmp2, sizeof(outer));
            carda = t_carda, cardb = t_cardb, pos = t_pos, statusa = t_statusa, statusb = t_statusb, know_a = t_knowa, know_b = t_knowb;
        }
        if (rate1 == -1 && rate2 == -1) return 1;
        else if (rate1 == -1 || (cardb == 7 && (newcard == 5 || newcard == 6))) return rate2;
        else if (rate2 == -1 || (newcard == 7 && (cardb == 5 || cardb == 6))) return rate1;
        else {
            return (0.5*rate1+0.5*rate2);
        }
    }
}


int main() {
     freopen("letter.in", "r", stdin);
     freopen("letter.out", "w", stdout);
    int T;
    scanf("%d", &T);
    while (T--) {
        memset(outer, 0, sizeof(0));
        memset(pile, 0, sizeof(0));
        cnt = lft = pos = carda = cardb = statusa = statusb = 0;
        scanf("%d", &cnt);
        for (int i=1; i<=cnt; i++) {
            scanf("%d", &pile[i]);
            outer[0]++;
            outer[pile[i]]++;
        }
        scanf("%d%d", &carda, &cardb);
        scanf("%d", &lft);
        outer[0]++; outer[lft]++;
        double ans = calc_win_rate(0, -1, -1);
        printf("%.2lf\%\n", ans*100);
    }
    
    return 0;
}
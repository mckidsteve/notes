#include <cstdio>
int solve(int x, int index)
{
	int c = 0, tmp = x, ans = x;
	while(tmp){
		c++, tmp /= 10;
	}
	for(int i = 0; i <= index; i++){
		for(int j = 0; j < c; j++){
			ans = ans * 10;
		}
		ans += x;
	}
	return ans;
}
int main()
{
	int n;
	while(~scanf("%d", &n)){
		while(n--){
			int tmp, ans = 0;
			for(int i = 0; i < 3; i++){
				scanf("%d", &tmp);
				ans += solve(tmp, !!i);
			}
			printf("%d\n", ans);
		}
	}
	return 0;
 } 
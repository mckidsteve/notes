#include <cstdio>
#include <iostream>
const int maxn = 1e5+10;
using namespace std;

int n, c[maxn], a, b, s;

int main() {
	scanf("%d", &n);
	s = 0;
	while (n --) {
		scanf("%d%d", &a, &b);
		if (a == 1) {
			int i;
			for (i = 1; i * i < b; i ++)
				if (b % i == 0)
					c[i] ++, c[b / i] ++;
			if (i * i == b)
				c[i] ++;
		}
		else
			s += c[b];
	}
	printf("%d", s);
}

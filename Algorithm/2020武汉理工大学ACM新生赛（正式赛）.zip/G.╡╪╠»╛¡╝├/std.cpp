#include <bits/stdc++.h>
using namespace std;
const int N=1e4+5;
const int inf=1e9;

int n,m;
int a[N],b[N],c[N];
int f[2][N];

int main(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)scanf("%d%d%d",&a[i],&b[i],&c[i]);
	int t=1;
	for(int i=1;i<=n;++i){
		int maxx=-inf;
		for(int j=1;j<=m;++j){
			f[t][j]=max(f[t^1][j],f[t^1][j-1]+a[i]); 
		    if(j>2)f[t][j]=max(f[t][j],a[i]+b[i]+c[i]*j+maxx); 
			if(j>=2)f[t][j]=max(f[t][j],f[t^1][j-2]+a[i]+b[i]),maxx=max(maxx,f[t^1][j-2]-c[i]*j);
		}
		t^=1;
	}
	printf("%d",f[n&1][m]);
	return 0;
}


#include<iostream>
using namespace std;
long long n,k,sum[12],x[6],y[6],a[6],vis[6],ans;
void dfs(int t,long long tot){
	ans=max(ans,tot);
	if(t>n) return;
	for(int i=1;i<=k;i++){
		if(!vis[i]){
			long long dx=t+x[i],dy=t+y[i];
			vis[i]=1;
			dfs(dy,tot+a[i]*(sum[min(n,dx-1)]-sum[t-1])+(sum[min(n,dy-1)]-sum[t-1]));
			vis[i]=0;
		}
	}
	dfs(t+1,tot+sum[t]-sum[t-1]);
}
int main(){
	cin>>n>>k;
	long long tmp;
	for(int i=1;i<=n;i++){
		cin>>tmp;
		sum[i]=tmp+sum[i-1];
	}
	for(int i=1;i<=k;i++){
		cin>>a[i]>>x[i]>>y[i];
	}
	dfs(1,0);
	cout<<ans;
}

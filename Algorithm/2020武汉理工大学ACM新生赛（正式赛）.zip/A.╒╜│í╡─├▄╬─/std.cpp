#include <bits/stdc++.h>
using namespace std;
char a[100 + 10], b[10 + 10];
int main()
{
    cin >> a + 1 >> b + 1;
    int lena = strlen(a + 1), lenb = strlen(b + 1);
    int cnt = 0;
    bool flag = true;
    for (int i = 1; i <= lena - lenb + 1; i++)
    {
        flag = true;
        for (int j = 1; j <= lenb; j++)
        {
            if (a[i + j - 1] != b[j])
            {
                flag = false; break;
            }
        }
        if (flag)
        {
            cnt++;
            if (cnt == 2)
            {
                cout << i; break;
            }
        }
    }
    return 0;
}